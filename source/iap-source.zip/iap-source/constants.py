OPEN_ID_PROVIDERS = (
    ('Google', 'google.com/accounts/o8/id'),
    ('Yahoo', 'yahoo.com'),
    ('MySpace', 'myspace.com'),
    ('AOL', 'aol.com'),
    ('MyOpenID', 'myopenid.com'),
)
POSTBACK_URL = 'http://iap-hello-world.appspot.com/postback-verify'
